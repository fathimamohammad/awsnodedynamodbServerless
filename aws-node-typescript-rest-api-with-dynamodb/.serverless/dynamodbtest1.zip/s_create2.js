
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'fathimamohammad',
  applicationName: 'service2',
  appUid: '86Ybr2bKyQxnNMl6bD',
  orgUid: 'JphSCkhK21rnySGrMb',
  deploymentUid: '6baf80fa-0b62-44b9-8e02-35c315c4dd48',
  serviceName: 'dynamodbtest1',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.5',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'dynamodbtest1-dev-create2', timeout: 6 };

try {
  const userHandler = require('./todos/create.js');
  module.exports.handler = serverlessSDK.handler(userHandler.create2, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}